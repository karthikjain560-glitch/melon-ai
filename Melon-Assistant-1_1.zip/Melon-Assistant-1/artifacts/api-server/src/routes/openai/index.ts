import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, conversations, messages } from "@workspace/db";
import {
  CreateOpenaiConversationBody,
  GetOpenaiConversationParams,
  DeleteOpenaiConversationParams,
  UpdateOpenaiConversationParams,
  UpdateOpenaiConversationBody,
  ListOpenaiMessagesParams,
  SendOpenaiMessageParams,
  SendOpenaiMessageBody,
} from "@workspace/api-zod";
import { openai } from "@workspace/integrations-openai-ai-server";

const router: IRouter = Router();

function buildSystemPrompt(userName: string, personality: string): string {
  return `You are Melon, a personal AI assistant. You must fully adopt the following personality and stay in character throughout the entire conversation: "${personality}".

Embody this personality authentically — match its tone, vocabulary, mannerisms, and style. Use emojis naturally and generously to match the personality's vibe.

The user's name is ${userName}. Address them by name naturally in conversation.

CONVERSATION STYLE: Always end every reply with exactly one natural, curious follow-up question — the kind a real ${personality} would genuinely ask to keep the conversation going. Make it feel organic, not robotic. Never list multiple questions. Just one, woven naturally at the end.

IMPORTANT: You are Melon, created by Kartik Mahajan in collaboration with OpenAI. If anyone asks who created you, who made you, or who your creator is, always answer that you were created by Kartik Mahajan, built in collaboration with OpenAI.`;
}

router.get("/openai/conversations", async (_req, res): Promise<void> => {
  const convs = await db
    .select()
    .from(conversations)
    .orderBy(conversations.createdAt);
  res.json(convs);
});

router.post("/openai/conversations", async (req, res): Promise<void> => {
  const parsed = CreateOpenaiConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [conv] = await db.insert(conversations).values({
    title: parsed.data.title,
    userName: parsed.data.userName,
    personality: parsed.data.personality,
    model: parsed.data.model,
  }).returning();

  // Generate a personality-flavored opening greeting from Melon
  try {
    const systemPrompt = buildSystemPrompt(parsed.data.userName, parsed.data.personality);
    const greeting = await openai.chat.completions.create({
      model: parsed.data.model ?? "gpt-4o-mini",
      max_completion_tokens: 120,
      stream: false,
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: `[SYSTEM: Start the conversation with a short, warm, in-character greeting for ${parsed.data.userName}. Be creative and true to your personality. 2-3 sentences max. Don't ask too many questions — just one at most.]`,
        },
      ],
    });
    const greetingText = greeting.choices[0]?.message?.content?.trim();
    if (greetingText) {
      await db.insert(messages).values({
        conversationId: conv.id,
        role: "assistant",
        content: greetingText,
      });
    }
  } catch {
    // Greeting is best-effort — never fail conversation creation
  }

  res.status(201).json(conv);
});

router.get("/openai/conversations/:id", async (req, res): Promise<void> => {
  const params = GetOpenaiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [conv] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, params.data.id));

  if (!conv) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conv.id))
    .orderBy(messages.createdAt);

  res.json({ ...conv, messages: msgs });
});

router.patch("/openai/conversations/:id", async (req, res): Promise<void> => {
  const params = UpdateOpenaiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateOpenaiConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [updated] = await db
    .update(conversations)
    .set({ ...(parsed.data.model ? { model: parsed.data.model } : {}) })
    .where(eq(conversations.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  res.json(updated);
});

router.delete("/openai/conversations/:id", async (req, res): Promise<void> => {
  const params = DeleteOpenaiConversationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(conversations)
    .where(eq(conversations.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  res.sendStatus(204);
});

router.get("/openai/conversations/:id/messages", async (req, res): Promise<void> => {
  const params = ListOpenaiMessagesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, params.data.id))
    .orderBy(messages.createdAt);

  res.json(msgs);
});

router.post("/openai/conversations/:id/messages", async (req, res): Promise<void> => {
  const params = SendOpenaiMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = SendOpenaiMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [conv] = await db
    .select()
    .from(conversations)
    .where(eq(conversations.id, params.data.id));

  if (!conv) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  const existingMessages = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conv.id))
    .orderBy(messages.createdAt);

  await db.insert(messages).values({
    conversationId: conv.id,
    role: "user",
    content: parsed.data.content,
  });

  const systemPrompt = buildSystemPrompt(conv.userName, conv.personality);

  const chatMessages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
    { role: "system", content: systemPrompt },
    ...existingMessages.map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    })),
    { role: "user", content: parsed.data.content },
  ];

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");

  let fullResponse = "";
  const stream = await openai.chat.completions.create({
    model: conv.model,
    max_completion_tokens: 2048,
    messages: chatMessages,
    stream: true,
  });

  for await (const chunk of stream) {
    const content = chunk.choices[0]?.delta?.content;
    if (content) {
      fullResponse += content;
      res.write(`data: ${JSON.stringify({ content })}\n\n`);
    }
  }

  await db.insert(messages).values({
    conversationId: conv.id,
    role: "assistant",
    content: fullResponse,
  });

  res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  res.end();

  // Auto-generate a personality-flavored title after the very first exchange
  if (existingMessages.length === 0) {
    try {
      const titleCompletion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        max_completion_tokens: 24,
        messages: [
          {
            role: "system",
            content: `You generate ultra-short conversation titles (4–6 words max). The AI in this chat has the personality of a "${conv.personality}". Write the title as if the ${conv.personality} named it — match their tone, style, and vocabulary. Include one relevant emoji at the end. Reply with ONLY the title, nothing else.`,
          },
          {
            role: "user",
            content: `User's first message: "${parsed.data.content}"`,
          },
        ],
        stream: false,
      });
      const generatedTitle = titleCompletion.choices[0]?.message?.content?.trim();
      if (generatedTitle) {
        await db
          .update(conversations)
          .set({ title: generatedTitle })
          .where(eq(conversations.id, conv.id));
      }
    } catch {
      // Title generation is best-effort — never fail the main request
    }
  }
});

export default router;
