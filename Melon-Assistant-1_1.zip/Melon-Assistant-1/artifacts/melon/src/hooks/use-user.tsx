import { useState, createContext, useContext } from "react";

interface UserContextType {
  userName: string | null;
  personality: string | null;
  model: string | null;
  setUserName: (name: string | null) => void;
  setPersonality: (personality: string | null) => void;
  setModel: (model: string | null) => void;
  resetUser: () => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [userName, setUserNameState] = useState<string | null>(() => localStorage.getItem("melon_userName"));
  const [personality, setPersonalityState] = useState<string | null>(() => localStorage.getItem("melon_personality"));
  const [model, setModelState] = useState<string | null>(() => localStorage.getItem("melon_model"));

  const setUserName = (name: string | null) => {
    setUserNameState(name);
    if (name) localStorage.setItem("melon_userName", name);
    else localStorage.removeItem("melon_userName");
  };

  const setPersonality = (p: string | null) => {
    setPersonalityState(p);
    if (p) localStorage.setItem("melon_personality", p);
    else localStorage.removeItem("melon_personality");
  };

  const setModel = (m: string | null) => {
    setModelState(m);
    if (m) localStorage.setItem("melon_model", m);
    else localStorage.removeItem("melon_model");
  };

  const resetUser = () => {
    setUserName(null);
    setPersonality(null);
    setModel(null);
  };

  return (
    <UserContext.Provider value={{ userName, personality, model, setUserName, setPersonality, setModel, resetUser }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
}
