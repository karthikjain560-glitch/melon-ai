import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useUser } from "@/hooks/use-user";
import { Search } from "lucide-react";
import { StarField } from "@/components/star-field";

const MODELS = [
  {
    id: "gpt-4o-mini",
    name: "GPT-4o mini",
    badge: "Recommended",
    badgeColor: "bg-primary/15 text-primary border-primary/25",
    emoji: "⚡",
    desc: "Fast, free, and great for everyday conversation.",
    capabilities: ["Fast replies", "128K context", "Free tier"],
  },
  {
    id: "gpt-4o",
    name: "GPT-4o",
    badge: "Most Capable",
    badgeColor: "bg-purple-500/15 text-purple-400 border-purple-500/25",
    emoji: "🧠",
    desc: "OpenAI's most powerful model — best for complex tasks.",
    capabilities: ["Smartest", "128K context", "Multimodal"],
  },
];

const SUGGESTIONS = [
  { label: "Friend",          emoji: "👫" },
  { label: "Teacher",         emoji: "📚" },
  { label: "Life Coach",      emoji: "🌟" },
  { label: "Doctor",          emoji: "🩺" },
  { label: "Comedian",        emoji: "😂" },
  { label: "Philosopher",     emoji: "🧐" },
  { label: "Pirate",          emoji: "🏴‍☠️" },
  { label: "Scientist",       emoji: "🔬" },
  { label: "Chef",            emoji: "🍳" },
  { label: "Lawyer",          emoji: "⚖️" },
  { label: "Poet",            emoji: "✍️" },
  { label: "Therapist",       emoji: "💆" },
  { label: "Historian",       emoji: "📜" },
  { label: "Fitness Trainer", emoji: "💪" },
  { label: "Astronaut",       emoji: "🚀" },
  { label: "Girlfriend",      emoji: "💕" },
  { label: "Boyfriend",       emoji: "❤️" },
  { label: "Manager",         emoji: "💼" },
  { label: "Storyteller",     emoji: "📖" },
  { label: "Motivator",       emoji: "🔥" },
];

const pageVariants = {
  initial: { opacity: 0, y: 28, scale: 0.97 },
  animate: { opacity: 1, y: 0,  scale: 1,    transition: { duration: 0.45 } },
  exit:    { opacity: 0, y: -20, scale: 0.97, transition: { duration: 0.3  } },
};

export default function Home() {
  const [, setLocation] = useLocation();
  const { userName, setUserName, setPersonality, setModel } = useUser();
  const [step, setStep] = useState<"name" | "personality" | "model">(userName ? "personality" : "name");
  const [tempName, setTempName] = useState(userName || "");
  const [search, setSearch] = useState("");

  const filtered = search.trim()
    ? SUGGESTIONS.filter((s) => s.label.toLowerCase().includes(search.toLowerCase()))
    : SUGGESTIONS;

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempName.trim()) { setUserName(tempName.trim()); setStep("personality"); }
  };

  const handlePersonalitySelect = (label: string) => {
    setPersonality(label);
    setStep("model");
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (search.trim()) handlePersonalitySelect(search.trim());
  };

  const handleModelSelect = (modelId: string) => {
    setModel(modelId);
    setLocation("/chat");
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 relative overflow-hidden">
      {/* Deep gradient background */}
      <div className="fixed inset-0 bg-gradient-to-br from-[hsl(225,35%,6%)] via-[hsl(230,25%,4%)] to-[hsl(220,20%,2%)] -z-10" />

      {/* Ambient glows */}
      <div className="fixed top-[-15%] left-[10%]  w-[600px] h-[500px] bg-primary/6  rounded-full blur-[130px] pointer-events-none -z-10" />
      <div className="fixed bottom-[-10%] right-[5%] w-[500px] h-[400px] bg-accent/5   rounded-full blur-[120px] pointer-events-none -z-10" />

      {/* Stars */}
      <StarField count={100} />

      <AnimatePresence mode="wait">

        {/* ── Step 1: Name ── */}
        {step === "name" && (
          <motion.div key="name" variants={pageVariants} initial="initial" animate="animate" exit="exit"
            className="w-full max-w-md flex flex-col items-center z-10">

            {/* Glowing melon logo */}
            <div className="mb-7 relative">
              <div className="absolute inset-0 rounded-full bg-primary/20 blur-2xl scale-150 animate-pulse" />
              <span className="relative text-7xl sm:text-8xl animate-melon-glow select-none">🍈</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2 text-center tracking-tight leading-tight">
              Hey, I'm{" "}
              <span className="text-primary text-glow-green">Melon</span>
            </h1>
            <p className="text-muted-foreground mb-8 text-center text-base sm:text-lg font-medium">
              Your personal AI ✨ — what's your name?
            </p>

            <form onSubmit={handleNameSubmit} className="w-full">
              <div className="relative">
                <Input
                  type="text"
                  placeholder="Enter your name..."
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  className="w-full h-14 bg-card/60 border-white/10 text-base sm:text-lg px-6 pr-36 rounded-full
                             focus-visible:ring-primary focus-visible:border-primary/50 backdrop-blur-xl
                             shadow-xl placeholder:text-muted-foreground/50 font-medium"
                  autoFocus
                />
                <Button
                  type="submit"
                  size="sm"
                  className="absolute right-2 top-2 h-10 rounded-full px-5 bg-primary text-primary-foreground
                             hover:bg-primary/90 transition-all font-semibold glow-green-sm"
                  disabled={!tempName.trim()}
                >
                  Let's go 💫
                </Button>
              </div>
            </form>
          </motion.div>
        )}

        {/* ── Step 2: Personality search ── */}
        {step === "personality" && (
          <motion.div key="personality" variants={pageVariants} initial="initial" animate="animate" exit="exit"
            className="w-full max-w-2xl flex flex-col items-center z-10">

            <div className="mb-5 relative">
              <div className="absolute inset-0 rounded-full bg-accent/20 blur-2xl scale-150" />
              <span className="relative text-5xl sm:text-6xl select-none">🎭</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2 text-center tracking-tight">
              Who should I be,{" "}
              <span className="text-primary text-glow-green">{userName}</span>?
            </h2>
            <p className="text-muted-foreground mb-7 text-center text-sm sm:text-base font-medium">
              Search or type any personality — I'll become it completely.
            </p>

            {/* Search */}
            <form onSubmit={handleSearchSubmit} className="w-full mb-5">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/60 pointer-events-none" />
                <Input
                  type="text"
                  placeholder="e.g. Pirate, Scientist, Shakespeare, Yoda..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full h-14 bg-card/60 border-white/10 text-sm sm:text-base pl-12 pr-36 rounded-full
                             focus-visible:ring-primary focus-visible:border-primary/50 backdrop-blur-xl
                             shadow-xl placeholder:text-muted-foreground/40 font-medium"
                  autoFocus
                />
                <AnimatePresence>
                  {search.trim() && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
                      className="absolute right-2 top-2"
                    >
                      <Button type="submit" size="sm"
                        className="h-10 rounded-full px-5 bg-primary text-primary-foreground hover:bg-primary/90 font-semibold glow-green-sm">
                        Use this ✨
                      </Button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </form>

            {/* Glowing tile grid */}
            <div className="w-full">
              <p className="text-[11px] text-muted-foreground/50 uppercase tracking-widest font-semibold mb-3 px-1">
                {search.trim() ? "Matching suggestions" : "Popular picks"}
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <AnimatePresence>
                  {filtered.map((s, idx) => (
                    <motion.button
                      key={s.label}
                      layout
                      initial={{ opacity: 0, scale: 0.88, y: 8 }}
                      animate={{ opacity: 1, scale: 1,    y: 0,  transition: { delay: idx * 0.025, duration: 0.25 } }}
                      exit={{ opacity: 0, scale: 0.88 }}
                      whileHover={{ scale: 1.04, y: -2 }}
                      whileTap={{ scale: 0.97 }}
                      onClick={() => handlePersonalitySelect(s.label)}
                      className="group flex flex-col items-center gap-1.5 py-4 px-2 rounded-2xl
                                 bg-card/50 border border-white/6 backdrop-blur-sm
                                 hover:bg-card/90 hover:border-primary/35
                                 hover:shadow-[0_0_20px_hsl(145_70%_48%/0.12),0_4px_20px_rgba(0,0,0,0.3)]
                                 transition-all duration-200 cursor-pointer"
                    >
                      <span className="text-2xl sm:text-3xl group-hover:scale-110 transition-transform duration-200 leading-none">
                        {s.emoji}
                      </span>
                      <span className="text-xs sm:text-[13px] font-semibold text-foreground/80 group-hover:text-primary transition-colors text-center leading-tight">
                        {s.label}
                      </span>
                    </motion.button>
                  ))}

                  {search.trim() && filtered.length === 0 && (
                    <motion.button
                      initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                      onClick={() => handlePersonalitySelect(search.trim())}
                      className="col-span-2 sm:col-span-4 flex items-center justify-center gap-2 py-4 px-4 rounded-2xl
                                 bg-primary/10 border border-primary/30 text-primary font-semibold
                                 hover:bg-primary/20 hover:shadow-[0_0_20px_hsl(145_70%_48%/0.2)] transition-all"
                    >
                      <span>✨</span>
                      <span>Use "{search.trim()}"</span>
                    </motion.button>
                  )}
                </AnimatePresence>
              </div>
            </div>

            <button onClick={() => setStep("name")}
              className="mt-8 text-xs text-muted-foreground/60 hover:text-muted-foreground transition-colors underline underline-offset-4">
              ← Change my name
            </button>
          </motion.div>
        )}

        {/* ── Step 3: Model ── */}
        {step === "model" && (
          <motion.div key="model" variants={pageVariants} initial="initial" animate="animate" exit="exit"
            className="w-full max-w-xl flex flex-col items-center z-10">

            <div className="mb-5 relative">
              <div className="absolute inset-0 rounded-full bg-accent/20 blur-2xl scale-150" />
              <span className="relative text-5xl sm:text-6xl select-none">🧬</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2 text-center tracking-tight">
              Pick your AI brain
            </h2>
            <p className="text-muted-foreground mb-8 text-center text-sm sm:text-base font-medium">
              You can switch models any time inside the chat.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
              {MODELS.map((m) => (
                <motion.button
                  key={m.id}
                  whileHover={{ scale: 1.02, y: -3 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleModelSelect(m.id)}
                  className="group relative flex flex-col items-start p-5 rounded-2xl text-left w-full
                             bg-card/50 border border-white/6 backdrop-blur-sm
                             hover:bg-card/90 hover:border-primary/30
                             hover:shadow-[0_0_30px_hsl(145_70%_48%/0.12),0_8px_32px_rgba(0,0,0,0.4)]
                             transition-all duration-250"
                >
                  <div className="flex items-center gap-3 mb-3 w-full">
                    <span className="text-3xl group-hover:scale-110 transition-transform duration-250">{m.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-base">{m.name}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border font-semibold ${m.badgeColor}`}>
                          {m.badge}
                        </span>
                      </div>
                    </div>
                  </div>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">{m.desc}</p>
                  <div className="flex flex-wrap gap-2">
                    {m.capabilities.map((cap) => (
                      <span key={cap} className="text-xs px-2.5 py-1 rounded-full bg-white/5 border border-white/8 text-muted-foreground/70 font-medium">
                        {cap}
                      </span>
                    ))}
                  </div>
                </motion.button>
              ))}
            </div>

            <button onClick={() => setStep("personality")}
              className="mt-8 text-xs text-muted-foreground/60 hover:text-muted-foreground transition-colors underline underline-offset-4">
              ← Back to personality
            </button>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
