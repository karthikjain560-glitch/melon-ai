import { useState, useEffect, useRef } from "react";
import { useLocation, useParams } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useUser } from "@/hooks/use-user";
import { Send, Menu, Plus, MessageSquare, Trash2, LogOut, ChevronDown, Check, Mic, MicOff } from "lucide-react";
import {
  useListOpenaiConversations,
  useCreateOpenaiConversation,
  useGetOpenaiConversation,
  useDeleteOpenaiConversation,
  useUpdateOpenaiConversation,
  getGetOpenaiConversationQueryKey,
  getListOpenaiConversationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { StarField } from "@/components/star-field";

const PERSONALITY_EMOJIS: Record<string, string> = {
  friend: "👫", teacher: "📚", manager: "💼", girlfriend: "💕",
  boyfriend: "❤️", cook: "🍳", doctor: "🩺", comedian: "😂",
  philosopher: "🧐", pirate: "🏴‍☠️", scientist: "🔬", lawyer: "⚖️",
  poet: "✍️", therapist: "💆", historian: "📜", astronaut: "🚀",
  storyteller: "📖", motivator: "🔥", "life coach": "🌟", "fitness trainer": "💪",
};

const MODELS = [
  { id: "gpt-4o-mini", emoji: "⚡", shortName: "GPT-4o mini", desc: "Fast & free — great for everyday chat" },
  { id: "gpt-4o",      emoji: "🧠", shortName: "GPT-4o",      desc: "Most capable — best for complex tasks" },
];
const MODEL_MAP = Object.fromEntries(MODELS.map((m) => [m.id, m]));

export default function Chat() {
  const [, setLocation] = useLocation();
  const params = useParams();
  const queryClient = useQueryClient();
  const { userName, personality, model, resetUser } = useUser();
  const conversationId = params.id ? parseInt(params.id) : null;

  const [input, setInput] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isModelMenuOpen, setIsModelMenuOpen] = useState(false);
  const modelMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!userName || !personality || !model) setLocation("/");
  }, [userName, personality, model, setLocation]);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (modelMenuRef.current && !modelMenuRef.current.contains(e.target as Node))
        setIsModelMenuOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const { data: conversations, isLoading: isLoadingConversations } = useListOpenaiConversations();
  const createConversation  = useCreateOpenaiConversation();
  const deleteConversation  = useDeleteOpenaiConversation();
  const updateConversation  = useUpdateOpenaiConversation();

  const { data: currentConversation } = useGetOpenaiConversation(
    conversationId!,
    { query: { enabled: !!conversationId, queryKey: getGetOpenaiConversationQueryKey(conversationId!) } }
  );

  const activeModel      = currentConversation?.model ?? model ?? "gpt-4o-mini";
  const mInfo            = MODEL_MAP[activeModel];
  const personalityEmoji = personality ? (PERSONALITY_EMOJIS[personality.toLowerCase()] ?? "🎭") : "🎭";
  const pInfo            = personality ? { emoji: personalityEmoji, label: personality } : null;

  useEffect(() => {
    if (scrollRef.current)
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [currentConversation?.messages, streamingContent]);

  const handleNewChat = () => {
    if (!userName || !personality) return;
    createConversation.mutate(
      { data: { title: "New Conversation ✨", userName, personality, model: model ?? "gpt-4o-mini" } },
      {
        onSuccess: (newConv) => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          setLocation(`/chat/${newConv.id}`);
          setIsSidebarOpen(false);
        },
      }
    );
  };

  const handleDeleteChat = (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    deleteConversation.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
          if (conversationId === id) setLocation("/chat");
        },
      }
    );
  };

  const handleModelSwitch = (newModel: string) => {
    setIsModelMenuOpen(false);
    if (!conversationId || newModel === activeModel) return;
    updateConversation.mutate(
      { id: conversationId, data: { model: newModel } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(conversationId) }) }
    );
  };

  const handleSendMessage = async (e?: React.FormEvent, directMessage?: string) => {
    e?.preventDefault();
    const messageText = directMessage ?? input;
    if (!messageText.trim() || isStreaming) return;

    let targetConvId = conversationId;
    if (!targetConvId) {
      if (!userName || !personality) return;
      const newConv = await createConversation.mutateAsync({
        data: { title: messageText.slice(0, 32) + "…", userName, personality, model: model ?? "gpt-4o-mini" },
      });
      targetConvId = newConv.id;
      setLocation(`/chat/${targetConvId}`);
    }

    const userMessage = messageText;
    if (!directMessage) setInput("");
    setIsStreaming(true);
    setStreamingContent("");

    if (targetConvId) {
      queryClient.setQueryData(getGetOpenaiConversationQueryKey(targetConvId), (old: any) => {
        if (!old) return old;
        return {
          ...old,
          messages: [
            ...old.messages,
            { id: Date.now(), conversationId: targetConvId, role: "user", content: userMessage, createdAt: new Date().toISOString() },
          ],
        };
      });
    }

    try {
      const response = await fetch(`/api/openai/conversations/${targetConvId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: userMessage }),
      });
      if (!response.body) throw new Error("No response body");

      const reader  = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let fullContent = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.done) break;
              if (data.content) { fullContent += data.content; setStreamingContent(fullContent); }
            } catch { }
          }
        }
      }

      queryClient.invalidateQueries({ queryKey: getGetOpenaiConversationQueryKey(targetConvId!) });
      queryClient.invalidateQueries({ queryKey: getListOpenaiConversationsQueryKey() });
    } catch (error) {
      console.error("Streaming error:", error);
    } finally {
      setIsStreaming(false);
      setStreamingContent("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSendMessage(); }
  };

  const toggleVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = true;

    let finalTranscript = "";

    recognition.onstart = () => setIsListening(true);

    recognition.onresult = (event: any) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const t = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalTranscript += t;
        else interim = t;
      }
      setInput((prev) => {
        const base = prev.replace(/\u200B.*$/, "");
        return base + (finalTranscript || interim ? (base ? " " : "") + (finalTranscript || interim) : "");
      });
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => {
      setIsListening(false);
      finalTranscript = "";
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full bg-sidebar/70 backdrop-blur-xl border-r border-sidebar-border/40">
      {/* Logo area */}
      <div className="px-5 pt-5 pb-3 flex items-center gap-2.5">
        <span className="text-2xl leading-none" style={{ filter: "drop-shadow(0 0 8px hsl(145 70% 48% / 0.7))" }}>🍈</span>
        <span className="font-bold text-lg tracking-tight text-foreground">Melon</span>
      </div>

      <div className="px-4 pb-4">
        <Button onClick={handleNewChat}
          className="w-full justify-start gap-2 bg-primary/10 text-primary hover:bg-primary/20
                     border border-primary/20 shadow-none font-semibold rounded-xl h-10">
          <Plus className="w-4 h-4" /> New Chat
        </Button>
      </div>

      <ScrollArea className="flex-1 px-3">
        <div className="space-y-1 pb-4">
          {isLoadingConversations ? (
            <div className="text-center text-sm text-muted-foreground/60 py-8">Loading… 🪄</div>
          ) : conversations?.length === 0 ? (
            <div className="text-center text-sm text-muted-foreground/60 py-8">No chats yet 🌌</div>
          ) : (
            conversations?.map((conv) => (
              <div key={conv.id}
                onClick={() => { setLocation(`/chat/${conv.id}`); setIsSidebarOpen(false); }}
                className={`group flex items-center justify-between px-3 py-2.5 rounded-xl cursor-pointer transition-all ${
                  conversationId === conv.id
                    ? "bg-primary/15 text-primary border border-primary/25 shadow-[0_0_12px_hsl(145_70%_48%/0.08)]"
                    : "hover:bg-white/5 text-foreground/70 border border-transparent"
                }`}
              >
                <div className="flex items-center gap-2.5 overflow-hidden min-w-0">
                  <MessageSquare className="w-3.5 h-3.5 shrink-0 opacity-60" />
                  <span className="truncate text-sm font-medium">{conv.title}</span>
                </div>
                <Button variant="ghost" size="icon"
                  className="w-6 h-6 shrink-0 opacity-0 group-hover:opacity-100 hover:text-destructive hover:bg-destructive/10 transition-all"
                  onClick={(e) => handleDeleteChat(e, conv.id)}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            ))
          )}
        </div>
      </ScrollArea>

      <div className="p-4 border-t border-sidebar-border/40 flex items-center justify-between bg-black/20">
        <div className="flex items-center gap-3 overflow-hidden min-w-0">
          <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center
                          text-primary font-bold shrink-0 text-sm shadow-[0_0_10px_hsl(145_70%_48%/0.2)]">
            {userName?.[0]?.toUpperCase()}
          </div>
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold">{userName}</div>
            <div className="truncate text-xs text-muted-foreground/60">{pInfo?.emoji} {pInfo?.label}</div>
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={resetUser}
          className="text-muted-foreground hover:text-destructive shrink-0 hover:bg-destructive/10 transition-all">
          <LogOut className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-[100dvh] text-foreground overflow-hidden selection:bg-primary/30 relative">
      {/* Background */}
      <div className="fixed inset-0 bg-gradient-to-br from-[hsl(225,35%,5%)] via-[hsl(230,25%,3%)] to-[hsl(220,20%,2%)] -z-10" />
      <StarField count={60} />

      {/* Desktop Sidebar */}
      <div className="hidden md:block w-72 h-full z-20 shrink-0 shadow-[4px_0_30px_rgba(0,0,0,0.5)]">
        <SidebarContent />
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col relative w-full h-full min-w-0 z-10">
        {/* Ambient glow behind messages */}
        <div className="absolute top-0 left-1/4 w-[600px] h-[350px] bg-primary/4 rounded-full blur-[120px] pointer-events-none" />

        {/* ── Header ── */}
        <header className="h-[60px] flex items-center justify-between px-4 shrink-0
                           bg-[hsl(225,30%,5%)]/80 backdrop-blur-xl border-b border-white/5 z-30">
          <div className="flex items-center gap-2 min-w-0">
            {/* Mobile menu */}
            <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden text-foreground/70 hover:text-foreground -ml-1">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-72 border-r-0 bg-transparent">
                <SidebarContent />
              </SheetContent>
            </Sheet>

            {/* Logo */}
            <span className="text-xl leading-none" style={{ filter: "drop-shadow(0 0 8px hsl(145 70% 48% / 0.65))" }}>🍈</span>
            <span className="font-bold tracking-tight hidden sm:inline-block">Melon</span>

            {/* Personality badge */}
            {pInfo && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full
                              bg-primary/10 border border-primary/20 text-primary
                              text-xs font-semibold shadow-[0_0_10px_hsl(145_70%_48%/0.1)]">
                <span className="text-sm">{pInfo.emoji}</span>
                <span className="hidden sm:inline">{pInfo.label}</span>
              </div>
            )}

            {/* Model switcher */}
            {conversationId && (
              <div className="relative" ref={modelMenuRef}>
                <button onClick={() => setIsModelMenuOpen((v) => !v)}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-full
                             bg-white/5 border border-white/8 hover:bg-white/10 hover:border-white/15
                             text-xs text-muted-foreground font-medium transition-all">
                  <span>{mInfo?.emoji ?? "🤖"}</span>
                  <span className="hidden sm:inline">{mInfo?.shortName ?? activeModel}</span>
                  <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${isModelMenuOpen ? "rotate-180" : ""}`} />
                </button>

                <AnimatePresence>
                  {isModelMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -6, scale: 0.96 }}
                      animate={{ opacity: 1, y: 0,  scale: 1 }}
                      exit={{ opacity: 0, y: -6, scale: 0.96 }}
                      transition={{ duration: 0.15 }}
                      className="absolute top-full left-0 mt-2 w-64 bg-card/95 border border-white/10
                                 rounded-2xl shadow-[0_8px_40px_rgba(0,0,0,0.6)] overflow-hidden z-50 backdrop-blur-xl"
                    >
                      <div className="px-3 pt-3 pb-1 text-[10px] font-bold uppercase tracking-widest text-muted-foreground/50">
                        Switch model
                      </div>
                      {MODELS.map((m) => {
                        const isActive = m.id === activeModel;
                        return (
                          <button key={m.id} onClick={() => handleModelSwitch(m.id)}
                            className={`w-full flex items-start gap-3 px-3 py-2.5 hover:bg-white/5 transition-colors text-left ${isActive ? "text-primary" : "text-foreground"}`}>
                            <span className="text-lg mt-0.5">{m.emoji}</span>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-sm font-semibold">{m.shortName}</span>
                                {isActive && <Check className="w-3 h-3 text-primary" />}
                              </div>
                              <p className="text-xs text-muted-foreground/70">{m.desc}</p>
                            </div>
                          </button>
                        );
                      })}
                      <div className="h-2" />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>
        </header>

        {/* ── Messages ── */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-6 scroll-smooth">
          <div className="max-w-3xl mx-auto space-y-5">

            {/* Empty state */}
            {!conversationId && (
              <motion.div
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
                className="flex flex-col items-center justify-center text-center pt-16 sm:pt-24 pb-8"
              >
                <div className="relative mb-5">
                  <div className="absolute inset-0 rounded-full bg-primary/20 blur-3xl scale-150" />
                  <div className="relative w-20 h-20 rounded-full bg-primary/10 border border-primary/25 flex items-center justify-center text-4xl
                                  shadow-[0_0_40px_hsl(145_70%_48%/0.2)]">
                    {pInfo?.emoji || "✨"}
                  </div>
                </div>
                <h2 className="text-2xl font-bold tracking-tight mb-2">
                  Ready, <span className="text-primary">{userName}</span>?
                </h2>
                <p className="text-muted-foreground/70 text-sm max-w-xs leading-relaxed">
                  Send a message to start chatting with your{" "}
                  <span className="text-foreground/80 font-medium">{pInfo?.label?.toLowerCase() || "AI assistant"}</span>.
                </p>
              </motion.div>
            )}

            {/* Messages */}
            {currentConversation?.messages?.map((msg, i) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 12, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.3, delay: i === 0 ? 0 : 0 }}
                className={`flex flex-col max-w-[88%] sm:max-w-[78%] ${msg.role === "user" ? "ml-auto items-end" : "mr-auto items-start"}`}
              >
                {msg.role === "assistant" && (
                  <div className="flex items-center gap-1.5 mb-1.5 px-1">
                    <span className="text-sm leading-none">{personalityEmoji}</span>
                    <span className="text-[11px] text-muted-foreground/50 font-medium">{pInfo?.label ?? "Melon"}</span>
                  </div>
                )}
                <div className={`px-4 sm:px-5 py-3 sm:py-3.5 rounded-2xl text-[14px] sm:text-[15px] leading-relaxed break-words whitespace-pre-wrap ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-tr-md bubble-glow-user font-medium"
                    : "bg-card/80 border border-white/8 text-foreground rounded-tl-md bubble-glow-ai backdrop-blur-sm"
                }`}>
                  {msg.content}
                </div>
              </motion.div>
            ))}

            {/* Streaming — text coming in */}
            {isStreaming && streamingContent && (
              <motion.div
                initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                className="flex flex-col max-w-[88%] sm:max-w-[78%] mr-auto items-start"
              >
                <div className="flex items-center gap-1.5 mb-1.5 px-1">
                  <span className="text-sm leading-none">{personalityEmoji}</span>
                  <span className="text-[11px] text-muted-foreground/50 font-medium">{mInfo?.shortName ?? activeModel} is typing…</span>
                </div>
                <div className="px-4 sm:px-5 py-3 sm:py-3.5 rounded-2xl rounded-tl-md bg-card/80 border border-white/8
                               text-foreground bubble-glow-ai backdrop-blur-sm text-[14px] sm:text-[15px] leading-relaxed break-words whitespace-pre-wrap">
                  {streamingContent}
                  <span className="inline-block w-[3px] h-[1.1em] ml-0.5 bg-primary rounded-sm animate-pulse align-middle" />
                </div>
              </motion.div>
            )}

            {/* Streaming — waiting for first token (thinking dots) */}
            {isStreaming && !streamingContent && (
              <motion.div
                initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                className="flex flex-col max-w-[88%] mr-auto items-start"
              >
                <div className="flex items-center gap-1.5 mb-1.5 px-1">
                  <span className="text-sm leading-none">{personalityEmoji}</span>
                  <span className="text-[11px] text-muted-foreground/50 font-medium">{mInfo?.shortName ?? activeModel} is thinking…</span>
                </div>
                <div className="px-5 py-4 rounded-2xl rounded-tl-md bg-card/80 border border-white/8 backdrop-blur-sm
                               bubble-glow-ai flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-primary dot-1" style={{ boxShadow: "0 0 6px hsl(145 70% 48% / 0.8)" }} />
                  <span className="w-2 h-2 rounded-full bg-primary dot-2" style={{ boxShadow: "0 0 6px hsl(145 70% 48% / 0.8)" }} />
                  <span className="w-2 h-2 rounded-full bg-primary dot-3" style={{ boxShadow: "0 0 6px hsl(145 70% 48% / 0.8)" }} />
                </div>
              </motion.div>
            )}


          </div>
        </div>

        {/* ── Input Area ── */}
        <div className="px-4 pb-4 pt-2 bg-gradient-to-t from-[hsl(225,30%,4%)] via-[hsl(225,30%,4%)]/95 to-transparent z-20 shrink-0">
          <div className="max-w-3xl mx-auto">
            <form onSubmit={handleSendMessage}
              className="relative flex items-end rounded-3xl overflow-hidden
                         bg-card/70 border border-white/8 backdrop-blur-xl
                         focus-within:border-primary/40 focus-within:shadow-[0_0_0_1px_hsl(145_70%_48%/0.2),0_0_30px_hsl(145_70%_48%/0.08)]
                         shadow-[0_4px_30px_rgba(0,0,0,0.5)] transition-all duration-300">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={isListening ? "Listening… 🎙️" : "Type or speak a message… 💭"}
                className="min-h-[56px] max-h-[180px] w-full resize-none border-0 bg-transparent
                           py-4 pl-5 pr-24 focus-visible:ring-0 shadow-none text-[14px] sm:text-[15px]
                           placeholder:text-muted-foreground/35 font-medium leading-relaxed"
                disabled={isStreaming}
                rows={1}
              />

              {/* Mic button */}
              <button
                type="button"
                onClick={toggleVoice}
                disabled={isStreaming}
                className="absolute right-14 bottom-2.5 h-9 w-9 rounded-full flex items-center justify-center
                           transition-all duration-200 disabled:opacity-30"
              >
                <AnimatePresence mode="wait">
                  {isListening ? (
                    <motion.span
                      key="listening"
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.8, opacity: 0 }}
                      className="relative flex items-center justify-center w-9 h-9 rounded-full
                                 bg-red-500/20 border border-red-500/40"
                    >
                      {/* Pulsing ring */}
                      <span className="absolute inset-0 rounded-full bg-red-500/20 animate-ping" />
                      <MicOff className="w-4 h-4 text-red-400 relative z-10" />
                    </motion.span>
                  ) : (
                    <motion.span
                      key="idle"
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.8, opacity: 0 }}
                      className="flex items-center justify-center w-9 h-9 rounded-full
                                 bg-white/5 border border-white/10 hover:bg-primary/10
                                 hover:border-primary/30 hover:text-primary text-muted-foreground
                                 transition-all duration-200"
                    >
                      <Mic className="w-4 h-4" />
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>

              {/* Send button */}
              <Button
                type="submit"
                size="icon"
                disabled={!input.trim() || isStreaming}
                className="absolute right-2.5 bottom-2.5 h-9 w-9 rounded-full bg-primary text-primary-foreground
                           hover:bg-primary/90 disabled:opacity-30 transition-all
                           shadow-[0_0_16px_hsl(145_70%_48%/0.4)] hover:shadow-[0_0_24px_hsl(145_70%_48%/0.6)]
                           disabled:shadow-none"
              >
                <Send className="w-4 h-4 ml-0.5" />
              </Button>
            </form>
            <p className="text-center mt-2.5 text-[11px] text-muted-foreground/40 font-medium">
              Melon can make mistakes — double-check important info ✨
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
