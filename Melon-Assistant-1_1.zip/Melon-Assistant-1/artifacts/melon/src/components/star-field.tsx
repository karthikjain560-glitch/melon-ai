import { useMemo } from "react";

interface Star {
  id: number;
  top: string;
  left: string;
  size: number;
  delay: string;
  duration: string;
  opacity: number;
}

function seededRandom(seed: number) {
  const x = Math.sin(seed + 1) * 10000;
  return x - Math.floor(x);
}

export function StarField({ count = 90 }: { count?: number }) {
  const stars: Star[] = useMemo(() =>
    Array.from({ length: count }, (_, i) => ({
      id: i,
      top: `${seededRandom(i * 3) * 100}%`,
      left: `${seededRandom(i * 3 + 1) * 100}%`,
      size: seededRandom(i * 3 + 2) * 2 + 0.5,
      delay: `${seededRandom(i * 7) * 5}s`,
      duration: `${2.5 + seededRandom(i * 11) * 3.5}s`,
      opacity: seededRandom(i * 13) * 0.5 + 0.08,
    })), [count]);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden>
      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute rounded-full bg-white"
          style={{
            top: star.top,
            left: star.left,
            width: `${star.size}px`,
            height: `${star.size}px`,
            opacity: star.opacity,
            animation: `star-pulse ${star.duration} ${star.delay} ease-in-out infinite alternate`,
          }}
        />
      ))}
    </div>
  );
}
